﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entities
{
    [Table("PEDIDO")]
    public class Pedido
    {
        [Key]
        public int ID { get; set; }
        public int USUARIO_ID { get; set; }
        public DateTime FECHA { get; set; }
    }
}
