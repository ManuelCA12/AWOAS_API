﻿using Data;
using Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class ProductoPedidoRepository
    {
        private readonly AppDbContext _context;
        public ProductoPedidoRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<ProductoPedido>> GetAllProductoPedidosAsync()
        {
            return await _context.productoPedidos.ToListAsync();
        }
        public async Task<ProductoPedido> GetProductoPedidoByIdAsync(int id)
        {
            return await _context.productoPedidos.FindAsync(id);
        }
        public async Task AddProductoPedido(ProductoPedido productoPedido)
        {
            await _context.productoPedidos.AddAsync(productoPedido);
        }
        public async Task UpdateProductoPedidoAsync(ProductoPedido productoPedido)
        {
            _context.productoPedidos.Update(productoPedido);
            await _context.SaveChangesAsync();
        }
        public async Task DeleteProductoPedidoAsync(int id)
        {
            var user = await _context.productoPedidos.FindAsync(id);
            if(user != null)
            {
                _context.productoPedidos.Remove(user);
                await _context.SaveChangesAsync();
            }
        }
    }
}
