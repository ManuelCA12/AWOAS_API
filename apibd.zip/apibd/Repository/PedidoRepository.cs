﻿using Data;
using Entities;
using Microsoft.EntityFrameworkCore;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class PedidoRepository : IPedidoRepository
    {
        private readonly AppDbContext _context;
        public PedidoRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Pedido>> GetAllPedidoAsync()
        {
            return await _context.Pedidos.ToListAsync();
        }
        public async Task<Pedido> GetPedidoByIdAsync(int id)
        {
            return await _context.Pedidos.FindAsync(id);
        }
        public async Task AddPedidoAsync(Pedido pedido)
        {
            await _context.Pedidos.AddAsync(pedido);
            await _context.SaveChangesAsync();
        }
        public async Task UpdatePedidoAsync( Pedido pedido)
        {
             _context.Pedidos.Update(pedido);
            await _context.SaveChangesAsync();
        }
        public async Task DeletePedidoAsync(int id)
        {
            var user = await _context.Pedidos.FindAsync(id);
            if (user != null)
            {
                _context.Pedidos.Remove(user);
                await _context.SaveChangesAsync();
            }
        }
    }
}
