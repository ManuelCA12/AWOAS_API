﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Interfaces
{
    public interface IProductoRepository
    {
        Task<List<Producto>> GetAllProductosAsync();
        Task<Producto> GetByIdProductosAsync(int id);
        Task AddProductosAsync(Producto producto);
        Task UpdateProductosAsync(Producto producto);
        Task DeleteProductosAsync(int id);
    }
}
