﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Interfaces
{
    public interface IPedidoRepository
    {
        Task<List<Pedido>> GetAllPedidoAsync();  // Obtener todos los productos
        Task<Pedido> GetPedidoByIdAsync(int id);   // Obtener un producto por ID
        Task AddPedidoAsync(Pedido pedido);      // Agregar un producto
        Task UpdatePedidoAsync(Pedido pedido);   // Actualizar un producto
        Task DeletePedidoAsync(int id);
    }
}
