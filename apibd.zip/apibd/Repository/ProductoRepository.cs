﻿using Data;
using Entities;
using Microsoft.EntityFrameworkCore;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class ProductoRepository : IProductoRepository
    {
        private readonly AppDbContext _context;
        public ProductoRepository(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Producto>> GetAllProductosAsync()
        {
            return await _context.Productos.ToListAsync();
        }
        public async Task<Producto> GetByIdProductosAsync(int id)
        {
            return await _context.Productos.FindAsync(id);
        }
        public async Task AddProductosAsync(Producto producto)
        {
            await _context.Productos.AddAsync(producto);
        }
        public async Task UpdateProductosAsync(Producto producto)
        {
            _context.Productos.Update(producto);
            await _context.SaveChangesAsync();
        }
        public async Task DeleteProductosAsync(int id)
        {
            var producto = await _context.Productos.FindAsync(id);
            if(producto != null)
            {
                _context.Productos.Remove(producto);
                await _context.SaveChangesAsync();
            }
        }
    }
}
