﻿using Entities;
using Repository;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class PedidoServices : IPedidoRepository
    {
        private readonly PedidoRepository _pedidoRepository;
        public PedidoServices(PedidoRepository pedidoRepository)
        {
             _pedidoRepository = pedidoRepository;
        }
        public async Task<List<Pedido>> GetAllPedidoAsync()
        {
            return await _pedidoRepository.GetAllPedidoAsync();
        }
        public async Task<Pedido> GetPedidoByIdAsync(int id)
        {
            return await _pedidoRepository.GetPedidoByIdAsync(id);
        }
        public async Task AddPedidoAsync(Pedido pedido)
        {
            await _pedidoRepository.AddPedidoAsync(pedido);
        }
        public async Task UpdatePedidoAsync(Pedido pedido)
        {
            await _pedidoRepository.UpdatePedidoAsync(pedido);
            
        } 
        public async Task DeletePedidoAsync(int id)
        {
            await _pedidoRepository.DeletePedidoAsync(id);
        }
    }
}
