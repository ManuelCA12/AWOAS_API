﻿using Entities;
using Repository;
using Repository.Interfaces;

namespace Services
{
    public class UsuarioServices : IUsuarioRepository
    {
        public readonly UsuarioRepository _usuarioRepository;
        public UsuarioServices(UsuarioRepository usuarioRepository)
        {
            _usuarioRepository = usuarioRepository;
        }
        public async Task<List<Usuario>> GetAllUsuariosAsync()
        {
            return await _usuarioRepository.GetAllUsuariosAsync();
        }
        public async Task<Usuario> GetByIdUsuariosAsync(int id)
        {
            return await _usuarioRepository.GetByIdUsuariosAsync(id);
        }
        public async Task AddUsuariosAsync(Usuario usuario)
        {
            await _usuarioRepository.AddUsuariosAsync(usuario);
        }
        public async Task UpdateUsuariosAsync(Usuario usuario)
        {
            await _usuarioRepository.UpdateUsuariosAsync(usuario);
        }
        public async Task DeleteUsuariosAsync(int id)
        {
            await _usuarioRepository.DeleteUsuariosAsync(id);
        }
    }
}
