﻿using Entities;
using Repository;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class ProductosServices : IProductoRepository
    {
        private readonly ProductoRepository _repository;
        public ProductosServices(ProductoRepository productoRepository)
        {
            _repository = productoRepository;
        }
        public async Task<List<Producto>> GetAllProductosAsync()
        {
            return await _repository.GetAllProductosAsync();
        }
        public async Task<Producto> GetByIdProductosAsync(int id)
        {
            return await _repository.GetByIdProductosAsync(id);
        }
        public async Task AddProductosAsync(Producto producto)
        {
            await _repository.AddProductosAsync(producto);
        }
        public async Task UpdateProductosAsync(Producto producto)
        {
            await _repository.UpdateProductosAsync(producto);
        }
        public async Task DeleteProductosAsync(int id)
        {
            await _repository.DeleteProductosAsync(id);
        }
    }
}
