﻿using Entities;
using Repository;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class ProductoPedidoServices : IProductoPedidoRepository
    {
        private readonly ProductoPedidoRepository _productoPedidoRepository;
        public ProductoPedidoServices(ProductoPedidoRepository productoPedidoRepository)
        {
            _productoPedidoRepository = productoPedidoRepository;
        }
        public async Task<List<ProductoPedido>> GetAllProductoPedidosAsync()
        {
            return await _productoPedidoRepository.GetAllProductoPedidosAsync();
        }
        public async Task<ProductoPedido> GetByIdProductoPedidosAsync(int id)
        {
            return await _productoPedidoRepository.GetProductoPedidoByIdAsync(id);
        }
        public async Task AddProductoPedidosAsync(ProductoPedido productoPedido)
        {
            await _productoPedidoRepository.AddProductoPedido(productoPedido);
        }
        public async Task UpdateProductoPedidosAsync(ProductoPedido productoPedido)
        {
            await _productoPedidoRepository.UpdateProductoPedidoAsync(productoPedido);
        }
        public async Task DeleteProductoPedidoAsync(int id)
        {
            await _productoPedidoRepository.DeleteProductoPedidoAsync(id);
        }
    }
}
