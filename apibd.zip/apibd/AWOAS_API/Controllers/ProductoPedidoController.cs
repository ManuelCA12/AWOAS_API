﻿using Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services;

namespace AWOAS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoPedidoController : ControllerBase
    {
        private readonly ProductoPedidoServices _productoPedidoServices;
        public ProductoPedidoController(ProductoPedidoServices productoPedidoServices)
        {
            _productoPedidoServices = productoPedidoServices;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductoPedido>>> GetAllProductoAsync()
        {
            var ProductPedido = await _productoPedidoServices.GetAllProductoPedidosAsync();
            return Ok(ProductPedido);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<ProductoPedido>> GetProuctoAsyncById(int id)
        {
            var productoPedido = await _productoPedidoServices.GetByIdProductoPedidosAsync(id);
            if (productoPedido == null)
            {
                return BadRequest();
            }
            return Ok(productoPedido);
        }
        [HttpPost]
        public async Task<ActionResult> AddProductoPedidoasync([FromBody] ProductoPedido productoPedido)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _productoPedidoServices.AddProductoPedidosAsync(productoPedido);
            return CreatedAtAction(nameof(GetProuctoAsyncById), new { id = productoPedido.IdProducto }, productoPedido);
        }
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateProductoPedidoAsync(int id, [FromBody] ProductoPedido productoPedido)
        {
            if (id != productoPedido.IdProducto)
            {
                return BadRequest();
            }
            var productExist = _productoPedidoServices.GetByIdProductoPedidosAsync(id);
            if (productExist == null)
            {
                return NotFound();
            }
            await _productoPedidoServices.UpdateProductoPedidosAsync(productoPedido);
            return NoContent();
        }
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteProductosAsync(int id)
        {
            var producto = await _productoPedidoServices.GetByIdProductoPedidosAsync(id);
            if (producto == null)
            {
                return NotFound();
            }
            await _productoPedidoServices.DeleteProductoPedidoAsync(id);
            return NoContent();
        }

    }
}
