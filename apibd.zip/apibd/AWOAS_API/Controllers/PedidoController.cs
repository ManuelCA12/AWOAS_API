﻿using Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services;

namespace AWOAS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidoController : ControllerBase
    {
        private readonly PedidoServices _pedidoService;
        public PedidoController(PedidoServices pedidoServices)
        {
            _pedidoService = pedidoServices;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Pedido>>> GetAllPedidos()
        {
            var pedido = await _pedidoService.GetAllPedidoAsync();
            return Ok(pedido);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<Pedido>> GetPedidoByIdAsync(int id)
        {
            var pedido = await _pedidoService.GetPedidoByIdAsync(id);
            if(pedido == null)
            {
                return NotFound();
            }
            return Ok(pedido);
        }
        [HttpPost]
        public async Task<ActionResult> AddPedidoAsync([FromBody] Pedido pedido)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _pedidoService.AddPedidoAsync(pedido);
            return CreatedAtAction(nameof(GetPedidoByIdAsync), new {id = pedido.ID}, pedido);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePedidoAsync(int id, [FromBody] Pedido pedido)
        {
            if(id != pedido.ID)
            {
                return BadRequest();
            }
            var pedidoExisting = await _pedidoService.GetPedidoByIdAsync(id);
            if (pedidoExisting == null)
            {
                return NotFound();
            }
             await _pedidoService.UpdatePedidoAsync(pedido);
             return NoContent();
        }
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeletePedidosAsync(int id)
        {
            var pedidoexisting = await _pedidoService.GetPedidoByIdAsync(id);
            if(pedidoexisting == null)
            {
                return NotFound();
            }
            await _pedidoService.DeletePedidoAsync(id);
            return NoContent();
        }
    }
}
