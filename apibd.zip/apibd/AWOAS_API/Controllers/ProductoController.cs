﻿using Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services;

namespace AWOAS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        private readonly ProductosServices _productosServices;
        public ProductoController(ProductosServices productosServices)
        {
            _productosServices = productosServices;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Producto>>> GetAllProductoAsync()
        {
            var producto = await _productosServices.GetAllProductosAsync();
            return Ok(producto);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<Pedido>> GetProuctoAsyncById(int id)
        {
            var producto = await _productosServices.GetByIdProductosAsync(id);
            if(producto == null)
            {
                return BadRequest();
            }
            return Ok(producto);
        }
        [HttpPost]
        public async Task<ActionResult> AddProductoasync([FromBody] Producto producto)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _productosServices.AddProductosAsync(producto);
            return CreatedAtAction(nameof(GetProuctoAsyncById), new {id = producto.IdProducto}, producto);
        }
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateproductosAsync(int id, [FromBody] Producto producto)
        {
            if(id != producto.IdProducto)
            {
                return BadRequest();
            }
            var productExist = _productosServices.GetByIdProductosAsync(id);
            if(productExist == null)
            {
                return NotFound();
            }
            await _productosServices.UpdateProductosAsync(producto);
            return NoContent();
        }
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteProductosAsync(int id)
        {
            var producto = await _productosServices.GetByIdProductosAsync(id);
            if(producto == null)
            {
                return NotFound();
            }
            await _productosServices.DeleteProductosAsync(id);
            return NoContent();
        }
    }
}
