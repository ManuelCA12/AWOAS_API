using Microsoft.EntityFrameworkCore;
using Services;
using Repository;
using Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

// Configuración de la cadena de conexión a MySQL
var connectionString = builder.Configuration.GetConnectionString("MySqlConnection");

// Registro del DbContext con MySQL y la cadena de conexión
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));

// Registro de los servicios y repositorios
builder.Services.AddScoped<UsuarioRepository>();
builder.Services.AddScoped<UsuarioServices>();
builder.Services.AddScoped<PedidoRepository>();
builder.Services.AddScoped<PedidoServices>();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
